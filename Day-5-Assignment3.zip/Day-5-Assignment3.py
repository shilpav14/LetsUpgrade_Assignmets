def is_match(list1,list2):
  for item in list2:
    if list1.index(item):
      print("It's a Match")
    else:
      print("It's Gone")
list1 = [1,5,6,4,1,2,3,5]
list2 = [1,1,5]
is_match(list1,list2)