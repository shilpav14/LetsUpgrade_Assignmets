def isPrime(x):
    for n in range(2,x):
        if x%n==0:
            return False
        else:
            return True
        

fObj=filter(isPrime, range(2500))
print ('Prime numbers between 2-2500:', list(fObj))